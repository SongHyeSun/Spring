package com.oracle.oBootBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
