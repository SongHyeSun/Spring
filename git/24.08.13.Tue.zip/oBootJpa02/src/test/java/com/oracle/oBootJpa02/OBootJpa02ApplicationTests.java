package com.oracle.oBootJpa02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootJpa02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
