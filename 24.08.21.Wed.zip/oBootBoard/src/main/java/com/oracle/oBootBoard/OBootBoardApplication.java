package com.oracle.oBootBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OBootBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(OBootBoardApplication.class, args);
	}

}
