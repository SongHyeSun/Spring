package com.oracle.oBootJpaApi01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OBootJpaApi01Application {

	public static void main(String[] args) {
		SpringApplication.run(OBootJpaApi01Application.class, args);
	}

}
