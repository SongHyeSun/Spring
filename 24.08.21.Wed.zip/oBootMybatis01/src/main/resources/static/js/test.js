/**
 * 
 */
	function getTest(){
		 alert("getTest->Start"); 
	
	}

	function teacherCheck() {

		alert("교번을 입력하세요");

	}