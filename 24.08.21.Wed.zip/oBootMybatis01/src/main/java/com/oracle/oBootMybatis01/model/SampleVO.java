package com.oracle.oBootMybatis01.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SampleVO {
	private Integer mno;
	private String 	firstName;
	private String 	lastName;
}
