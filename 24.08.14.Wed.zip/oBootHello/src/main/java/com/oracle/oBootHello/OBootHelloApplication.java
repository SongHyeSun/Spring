package com.oracle.oBootHello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OBootHelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(OBootHelloApplication.class, args);
	}

}
