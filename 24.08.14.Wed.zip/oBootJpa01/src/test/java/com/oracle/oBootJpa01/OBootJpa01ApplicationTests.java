package com.oracle.oBootJpa01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootJpa01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
